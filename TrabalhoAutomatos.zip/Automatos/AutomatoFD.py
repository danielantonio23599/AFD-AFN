import xml.dom.minidom as dom
import xml.etree.cElementTree as ETc
class AutomatoFD:
    def __init__(self, Alfabeto):
        Alfabeto = str(Alfabeto)
        self.estados = set()
        self.alfabeto = Alfabeto
        self.transicoes = dict() # dicionario
        self.inicial = None # nada
        self.finais = set() # conjunto vazio

    def limpaAfd(self):
        """Inicializa varialveis utilizadas no processamento de cadeias"""
        self.__deuErro = False
        self.__estadoAtual = self.inicial

    def criaEstado(self,id, inicial = False, final = False):
        """Cria o estado int(id), se ele ainda nao existe, e retorna True.
        Se o estado int(id) já existe, não faz nada e retorna False."""
        id = int(id)
        if id in self.estados:
            return False
        self.estados = self.estados.union({id})
        if inicial:
            self.inicial = id
        if final:
            self.finais = self.finais.union({id})

        return True

    def criaTransicao(self, origem, destino, simbolo):
        """Cria a transição (origem, simbolo)--> destino, se os parametros são validos, retorna
         True . Caso contrario, nao faz nada e retorna False"""
        origem = int(origem)
        destino = int(destino)
        simbolo = str(simbolo)
        if not origem in self.estados:
            return False
        if not destino in self.estados:
            return False
        if len(simbolo) != 1 or not simbolo in self.alfabeto:
            return False
        self.transicoes[(origem, simbolo)] = destino
        return True

    def mudaEstadoInicial(self, id):
        """Define um estado já existente como inicial"""
        if not id in self.estados:
            return
        self.inicial = id

    def mudaEstadoFinal(self, id, final):
        """Define se um estado ja existente eh final ou nao."""
        if not id in self.estados:
            return
        if final:
            self.finais = self.finais.union({id})
        else:
            self.finais = self.finais.difference({id})

    def move(self, cadeia):
        """Partindo do estado atual,  processa a cadeia e
         retorna o estado de parada. Se ocorrer erro, liga
          a variavel __deuErro."""
        for simbolo in cadeia:
            if not simbolo in self.alfabeto:
                self.__deuErro = True
                break
            if (self.__estadoAtual, simbolo) in self.transicoes.keys():
                novoEstado = self.transicoes[(self.__estadoAtual, simbolo)]
                self.__estadoAtual = novoEstado
            else:
                self.__deuErro = True
                break
        return  self.__estadoAtual

    def deuErro(self):
        return self.__deuErro

    def estadoAtual(self):
        return self.__estadoAtual

    def estadoFinal(self, id):
        return  id in self.finais

    def estadoInicial(self, id):
        return  id in self.inicial

    def lerAFD(self, caminho):
        root = ETc.parse(str(caminho)).getroot()
        # ler alfabeto
        alfabeto = '';
        for type_tag in root.findall('automaton/transition'):
            simbolo = type_tag.find('read').text
            if len(simbolo) != 1 or not simbolo in alfabeto:
                alfabeto += simbolo

        # cria afd
        afd = AutomatoFD(alfabeto)
        # insere os estados
        for type_tag in root.findall('automaton/state'):
            id = type_tag.get('id')
            inicial = type_tag.find('initial')
            final = type_tag.find('final')
            afd.criaEstado(id)

            if inicial is not None:
                afd.mudaEstadoInicial(int(id))
            if final is not None:
                afd.mudaEstadoFinal(int(id), True)

        # cria as transições
        for type_tag in root.findall('automaton/transition'):
            origem = type_tag.find('from').text
            destino = type_tag.find('to').text
            simbolo = type_tag.find('read').text
            afd.criaTransicao(origem, destino, simbolo)
        return afd

    def salvaAFD(self,caminho):
        root = ETc.Element("structure")
        ETc.SubElement(root, "type").text = "fa"
        doc = ETc.SubElement(root, "automaton")
        for e in self.estados:
            sub =  ETc.SubElement(doc, "state", id=str(e), name=str(e+1))
            if e == self.inicial:
                ETc.SubElement(sub,"initial")
            if self.estadoFinal(int(e)):
                ETc.SubElement(sub, "final")
        for (e, a) in self.transicoes.keys():
            tran = ETc.SubElement(doc, "transition")
            d = self.transicoes[(e, a)]
            ETc.SubElement(tran, "from").text = str(e)
            ETc.SubElement(tran, "to").text = str(d)
            ETc.SubElement(tran, "read").text = str(a)
        tree = ETc.ElementTree(root)

        tree.write("{}.jff".format(caminho) ,encoding='utf8', method='xml', short_empty_elements=True)

    def criaCopia(self):
        afd = self
        return afd

    def __str__(self):
        """Retorna string descrevendo o AFD. Util para debug."""
        s = 'AFD(E, A, T, i, F): \n'
        s+= '   E = { '
        for e in self.estados:
            s += '{}, '.format(str(e))
        s += '} \n'
        s += '   A = { '
        for a in self.alfabeto:
            s += "'{}', ".format(a)
        s += '} \n'
        s += '   T = { '
        for(e,a) in self.transicoes.keys():
            d = self.transicoes[(e, a)]
            s += "({},'{}')-->{}, ".format(e, a, d)
        s += '} \n'
        s += '    i = {} \n'.format(self.inicial)
        s += '    F= { '
        for e in self.finais:
            s += '{}, '.format(str(e))
        s += '}'
        return s

    def estadosEquivalentes(self):
        """Retorna um dicionario com os Estados True como equivalentes e False como não Equivalentes"""
        tabelaEstEqui = dict()
        """Estados Trivialmente Não Equivalentes, serão setados como False"""
        for y in range(1, len(self.estados)):
            for x in range(0, (len(self.estados)-1)):
                if (y > x):
                        r = self.setEstadoTrivialmenteDesequivalentes(list(self.estados)[x], list(self.estados)[y]  )
                        tabelaEstEqui[list(self.estados)[x], list(self.estados)[y]] = r
                else:
                    break
        """Estados não Equivalentes"""
        """percorre o dicionario """
        roda = True
        cont = 0
        """Roda ate que não tenha feito mais nenhuma alteração"""
        while roda:
            cont = 0
            for (x, y) in tabelaEstEqui.keys():
                v = tabelaEstEqui[(x, y)]

                if(v):
                    """e verifica os estados que estão como True se não são equivalentes
                            , caso seja verdade, define como False"""
                    r = self.isEstadoEquivalente(tabelaEstEqui ,x, y)
                    tabelaEstEqui[x, y] = r
                    if(r == False):
                        cont+=1
            if(cont == 0):
                roda = False
        return tabelaEstEqui;

    def isEstadoEquivalente(self,tabelaEstEqui,x = 0 , y = 0):
        for a in self.alfabeto:
            x1 = self.transicoes[(x, a)]
            y1 = self.transicoes[(y, a)]
            if(x1 < y1 ):
                v = tabelaEstEqui[(x1,y1)]
                if(v == False):
                    return False
            elif(y1 < x1):
                v = tabelaEstEqui[(y1,x1)]
                if(v == False):
                    return False
        return True

    def setEstadoTrivialmenteDesequivalentes(self, estado1,estado2):
        """2 Estados, sendo igualmente finais ou não finais serão definidos como True, o restante False """
        if((self.estadoFinal(estado1) and self.estadoFinal(estado2)) or
                (not self.estadoFinal(estado1) and not self.estadoFinal(estado2))):
            return True;
        else:
            return False;

    def minimizaAFD(self):
        estadosEqui = self.estadosEquivalentes();
        for (x, y) in estadosEqui.keys():
            v = estadosEqui[(x, y)]
            """verifica estados que são equivalentes"""
            if(v):
                """transições que chegam no estado y são passadas para chegar no X"""
                for (e, a) in self.transicoes.keys():
                    d = self.transicoes[(e, a)]
                    if(d == y):
                        self.transicoes[(e, a)] = x
                """Remove as transições a partir de Y"""
                for a in self.alfabeto:
                  del self.transicoes[(y,a)]
                """Remove estado """
                self.estados.remove(y)
        return  self

    def multiplicaAFD(self, afd1, afd2):
        afd = AutomatoFD(self.alfabeto)
        """Cria dicionario de Estados"""
        estados = dict()
        cont = 0
        """Cria estados"""
        for i in afd1.estados:
            for j in afd2.estados:
                estados[(i, j)] = cont
                afd.criaEstado(cont)
                """Verifica se os dois são Estados Iniciais"""
                if (i == afd1.inicial and j == afd2.inicial):
                    afd.mudaEstadoInicial(cont)
                cont += 1
        """Cria Transições"""
        for (i,a) in afd1.transicoes.keys():
            for (j, a) in afd2.transicoes.keys():
                for a in self.alfabeto:
                    o = estados[(i, j)]
                    i2 = afd1.transicoes[(i,a)]
                    j2 = afd2.transicoes[(j,a)]
                    d = estados[(i2,j2)]
                    afd.criaTransicao(o,d,a)
        return afd,estados

    def equivalenciaEntreAFDs(self, afd1, afd2):
        afd = AutomatoFD(self.alfabeto)
        """Cria dicionario de Estados"""
        estados = dict()
        cont = 0
        """Cria estados"""
        for i in afd1.estados:
            estados[(i,'afd1')] = cont
            afd.criaEstado(cont)
            """Verifica se é Estado Inicial"""
            if (i == afd1.inicial):
                afd.mudaEstadoInicial(cont)
            """Verifica se é Estado Final"""
            if (afd1.estadoFinal(i)):
                afd.mudaEstadoFinal(cont,True)
            cont += 1
        for j in afd2.estados:
            estados[(j, 'afd2')] = cont
            afd.criaEstado(cont)
            """Verifica se é Estado Inicial"""
            if (j == afd2.inicial):
                afd.mudaEstadoInicial(cont)
            """Verifica se é Estado Final"""
            if (afd2.estadoFinal(j)):
                afd.mudaEstadoFinal(cont, True)
            cont += 1
        """Cria Transições AFD1 """
        for (i,a) in afd1.transicoes.keys():
            for a in self.alfabeto:
                 o = estados[(i,'afd1')]
                 i2 = afd1.transicoes[(i,a)]
                 d = estados[(i2,'afd1')]
                 afd.criaTransicao(o,d,a)
        """Cria Transições AFD2 """
        for (i, a) in afd2.transicoes.keys():
            for a in self.alfabeto:
                o = estados[(i, 'afd2')]
                i2 = afd2.transicoes[(i, a)]
                d = estados[(i2, 'afd2')]
                afd.criaTransicao(o, d, a)
        """Verifica quais estados são equivalentes"""
        estadosEqui = afd.estadosEquivalentes()
        """Verifica se os dois estados iniciais são equivalentes"""
        x = afd1.inicial
        y = afd2.inicial
        v = estadosEqui[(x, y)]
        return v, afd, estadosEqui

    def uniaoAFD(self,afd1,afd2):
        afd = AutomatoFD(self.alfabeto)
        afd,estados = afd.multiplicaAFD(afd1,afd2)
        """Verifica se um dos dois são de Estados Final"""
        for i in afd1.estados:
            for j in afd2.estados:
                if (afd1.estadoFinal(int(i)) or afd2.estadoFinal(int(j))):
                    e = estados[(i,j)]
                    afd.mudaEstadoFinal(e, True)
        return afd

    def intercessaoAFD(self,afd1,afd2):
        afd = AutomatoFD(self.alfabeto)
        afd,estados = afd.multiplicaAFD(afd1,afd2)
        """Verifica se os dois são Estados Finais"""
        for i in afd1.estados:
            for j in afd2.estados:
                if (afd1.estadoFinal(int(i)) and afd2.estadoFinal(int(j))):
                    e = estados[(i,j)]
                    afd.mudaEstadoFinal(e, True)
        return afd

    def diferencaAFD(self,afd1,afd2):
        afd = AutomatoFD(self.alfabeto)
        afd,estados = afd.multiplicaAFD(afd1,afd2)
        """Verifica se AFD1 é Estado Final e AFD2 não é Final"""
        for i in afd1.estados:
            for j in afd2.estados:
                if (afd1.estadoFinal(int(i)) and (not afd2.estadoFinal(int(j)))):
                    e = estados[(i,j)]
                    afd.mudaEstadoFinal(e, True)
        return afd

    def complementoAFD(self,afd1,afd2):
        return self.diferencaAFD(afd2,afd1)

    """#################Escripts de teste#################################"""
    def testeSalvaAFDarquivo(self):
        """Ceria Autonomo"""
        afd = AutomatoFD('ab')
        for i in range(0, 6):
            afd.criaEstado(i)
        afd.mudaEstadoInicial(1)
        afd.mudaEstadoFinal(4, True)
        afd.mudaEstadoFinal(5, True)
        afd.criaTransicao(0, 1, 'b')
        afd.criaTransicao(0, 2, 'a')
        afd.criaTransicao(1, 1, 'a')
        afd.criaTransicao(1, 0, 'b')
        afd.criaTransicao(2, 4, 'a')
        afd.criaTransicao(2, 5, 'b')
        afd.criaTransicao(3, 5, 'a')
        afd.criaTransicao(3, 4, 'b')
        afd.criaTransicao(4, 3, 'a')
        afd.criaTransicao(4, 2, 'b')
        afd.criaTransicao(5, 2, 'a')
        afd.criaTransicao(5, 3, 'b')
        print(afd)
        """Salva Aoutonomo de arquivo"""
        afd.salvaAFD("./assets/afd")

    def testeLerAFDarquivo(self):
        """Ler Autonomo de arquivo"""
        print("Lendo afd de um arquivo .jff")
        afd = self.lerAFD("./assets/fd.jff")
        print(afd)

    def testeCriaCopia(self):
        """Ceria Autonomo"""
        afd = AutomatoFD('ab')
        for i in range(0, 6):
            afd.criaEstado(i)
        afd.mudaEstadoInicial(1)
        afd.mudaEstadoFinal(4, True)
        afd.mudaEstadoFinal(5, True)
        afd.criaTransicao(0, 1, 'b')
        afd.criaTransicao(0, 2, 'a')
        afd.criaTransicao(1, 1, 'a')
        afd.criaTransicao(1, 0, 'b')
        afd.criaTransicao(2, 4, 'a')
        afd.criaTransicao(2, 5, 'b')
        afd.criaTransicao(3, 5, 'a')
        afd.criaTransicao(3, 4, 'b')
        afd.criaTransicao(4, 3, 'a')
        afd.criaTransicao(4, 2, 'b')
        afd.criaTransicao(5, 2, 'a')
        afd.criaTransicao(5, 3, 'b')
        print(afd)
        afd2 = afd.criaCopia()
        print(afd2)

    def testeEstadosEquivalente(self):
        """Ceria Autonomo"""
        afd = AutomatoFD('ab')
        for i in range(0, 6):
            afd.criaEstado(i)
        afd.mudaEstadoInicial(1)
        afd.mudaEstadoFinal(4, True)
        afd.mudaEstadoFinal(5, True)
        afd.criaTransicao(0, 1, 'b')
        afd.criaTransicao(0, 2, 'a')
        afd.criaTransicao(1, 1, 'a')
        afd.criaTransicao(1, 0, 'b')
        afd.criaTransicao(2, 4, 'a')
        afd.criaTransicao(2, 5, 'b')
        afd.criaTransicao(3, 5, 'a')
        afd.criaTransicao(3, 4, 'b')
        afd.criaTransicao(4, 3, 'a')
        afd.criaTransicao(4, 2, 'b')
        afd.criaTransicao(5, 2, 'a')
        afd.criaTransicao(5, 3, 'b')
        print(afd)
        print("##################Estados equivalentes###################")
        tabelaEstEqui = afd.estadosEquivalentes()
        for (x, y) in tabelaEstEqui.keys():
            v = tabelaEstEqui[(x, y)]
            print("({} e {})-->{}, ".format(x, y, v))

    def testeEquivalenciaAFDs(self):
        afd = AutomatoFD('ab')
        afd1, afd2 = self.afdsTest()
        print(afd1)
        print(afd2)
        """Equivalencia entre AFDs"""
        v, afd, estadosEqui = afd.equivalenciaEntreAFDs(afd1, afd2)
        if(v):
            print("Os AFDs são equivalentes!!")
        else:
            print("Os AFDs NÂO são equivalentes!!")

    def testeMinimizacaoAFD(self):
        """Ceria Autonomo"""
        afd = AutomatoFD('ab')
        for i in range(0, 6):
            afd.criaEstado(i)
        afd.mudaEstadoInicial(1)
        afd.mudaEstadoFinal(4, True)
        afd.mudaEstadoFinal(5, True)
        afd.criaTransicao(0, 1, 'b')
        afd.criaTransicao(0, 2, 'a')
        afd.criaTransicao(1, 1, 'a')
        afd.criaTransicao(1, 0, 'b')
        afd.criaTransicao(2, 4, 'a')
        afd.criaTransicao(2, 5, 'b')
        afd.criaTransicao(3, 5, 'a')
        afd.criaTransicao(3, 4, 'b')
        afd.criaTransicao(4, 3, 'a')
        afd.criaTransicao(4, 2, 'b')
        afd.criaTransicao(5, 2, 'a')
        afd.criaTransicao(5, 3, 'b')
        print(afd)
        print("AFD minimizado")
        afd = afd.minimizaAFD()
        print(afd)

    def testeMultiplicacaoAFD(self):
        afd = AutomatoFD('ab')
        afd1, afd2 = self.afdsTest()
        print("AFD 1")
        print(afd1)
        print("AFD 2")
        print(afd2)
        afd,estados = afd.multiplicaAFD(afd1,afd2)
        print("AFD do resultado da multiplicação")
        print("OBS: o algoritimo de multiplicação não retona os estados finais,"
              " pois isso depende da operação entre conjuntos (União,intercessão,diferença e complemento")
        print(afd)
    def afdsTest(self):
        afd1 = AutomatoFD('ab')
        afd2 = AutomatoFD('ab')
        for i in range(1, 4):
            afd1.criaEstado(i)
        afd1.mudaEstadoInicial(1)
        afd1.mudaEstadoFinal(2, True)
        afd1.criaTransicao(1, 3, 'a')
        afd1.criaTransicao(1, 2, 'b')
        afd1.criaTransicao(2, 1, 'a')
        afd1.criaTransicao(2, 2, 'b')
        afd1.criaTransicao(3, 3, 'a')
        afd1.criaTransicao(3, 2, 'b')
        for i in range(4, 6):
            afd2.criaEstado(i)
        afd2.mudaEstadoInicial(4)
        afd2.mudaEstadoFinal(5, True)
        afd2.criaTransicao(4, 5, 'a')
        afd2.criaTransicao(4, 4, 'b')
        afd2.criaTransicao(5, 4, 'a')
        afd2.criaTransicao(5, 5, 'b')
        return afd1,afd2
    def testeUniãoAFDs(self):
        afd = AutomatoFD('ab')
        afd1,afd2 = self.afdsTest()
        print("AFD 1")
        print(afd1)
        print("AFD 2")
        print(afd2)
        afd = afd.uniaoAFD(afd1, afd2)
        print("AFD do resultado da união")
        print(afd)
    def testeIntercessaoAFDs(self):
        afd = AutomatoFD('ab')
        afd1,afd2 = self.afdsTest()
        print("AFD 1")
        print(afd1)
        print("AFD 2")
        print(afd2)
        afd = afd.intercessaoAFD(afd1, afd2)
        print("AFD do resultado da intercessao ")
        print(afd)
    def testeDiferençaAFDs(self):
        afd = AutomatoFD('ab')
        afd1,afd2 = self.afdsTest()
        print("AFD 1")
        print(afd1)
        print("AFD 2")
        print(afd2)
        afd = afd.diferencaAFD(afd1, afd2)
        print("AFD do resultado da diferença ")
        print(afd)
    def testeComplenetoAFDs(self):
        afd = AutomatoFD('ab')
        afd1,afd2 = self.afdsTest()
        print("AFD 1")
        print(afd1)
        print("AFD 2")
        print(afd2)
        afd = afd.complementoAFD(afd1, afd2)
        print("AFD do resultado da complemento ")
        print(afd)

if __name__ == '__main__':
    """Ceria Autonomo AFD"""
    afd = AutomatoFD('')



