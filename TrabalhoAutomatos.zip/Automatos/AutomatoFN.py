import xml.etree.ElementTree as ET
import xml.etree.cElementTree as ETc
from collections import defaultdict

from AutomatoFD import AutomatoFD


class AutomatoFN:
    def __init__(self, Alfabeto):
        Alfabeto = str(Alfabeto)
        self.estados = set()
        self.alfabeto = Alfabeto
        self.transicoes = defaultdict(list) # dicionario
        self.iniciais = set() # conjunto vazio
        self.finais = set() # conjunto vazio

    def limpaAfn(self):
        """Inicializa varialveis utilizadas no processamento de cadeias"""
        self.__deuErro = False
        self.__estadoAtual = self.iniciais

    def criaEstadoFN(self,id, inicial = False, final = False):
        """Cria o estado int(id), se ele ainda nao existe, e retorna True.
        Se o estado int(id) já existe, não faz nada e retorna False."""
        id = int(id)
        if id in self.estados:
            return False
        self.estados = self.estados.union({id})
        if inicial:
            self.iniciais = self.iniciais.union({id})
        if final:
            self.finais = self.finais.union({id})

        return True

    def criaTransicao(self, origem, destino, simbolo):
        """Cria a transição (origem, simbolo)--> destino, se os parametros são validos, retorna
         True . Caso contrario, nao faz nada e retorna False"""
        origem = int(origem)
        destino = int(destino)
        simbolo = str(simbolo)
        if not origem in self.estados:
            return False
        if not destino in self.estados:
            return False
        if len(simbolo) != 1 or not simbolo in self.alfabeto:
            return False
        self.transicoes[(origem, simbolo)].append(destino)
        return True

    def mudaEstadoInicialFN(self, id, inicial):
        """Define se um estado ja existente eh inicial ou nao."""
        if not id in self.estados:
            return
        if inicial:
            self.iniciais = self.iniciais.union({id})
        else:
            self.iniciais = self.iniciais.difference({id})

    def mudaEstadoFinalFN(self, id, final):
        """Define se um estado ja existente eh final ou nao."""
        if not id in self.estados:
            return
        if final:
            self.finais = self.finais.union({id})
        else:
            self.finais = self.finais.difference({id})

    def deuErro(self):
        return self.__deuErro

    def estadoAtual(self):
        return self.__estadoAtual

    def estadoFinal(self, id):
        return  id in self.finais

    def estadoInicial(self, id):
        return  id in self.iniciais

    def lerAFN(self, caminho):
        root = ET.parse(str(caminho)).getroot()
        # ler alfabeto
        alfabeto = '';
        for type_tag in root.findall('automaton/transition'):
            simbolo = type_tag.find('read').text
            if len(simbolo) != 1 or not simbolo in alfabeto:
                alfabeto += simbolo
        # cria afn
        afn = AutomatoFN(alfabeto)
        # insere os estados
        for type_tag in root.findall('automaton/state'):
            id = type_tag.get('id')
            inicial = type_tag.find('initial')
            final = type_tag.find('final')
            afn.criaEstadoFN(id)

            if inicial is not None:
                afn.mudaEstadoInicialFN(int(id),True)
            if final is not None:
                afn.mudaEstadoFinalFN(int(id), True)

        # cria as transições
        for type_tag in root.findall('automaton/transition'):
             origem = type_tag.find('from').text
             destino =type_tag.find('to').text
             simbolo = type_tag.find('read').text
             afn.criaTransicao(origem, destino, simbolo)
        return afn

    def salvaAFN(self,caminho):
        root = ETc.Element("structure")
        ETc.SubElement(root, "type").text = "fa"
        doc = ETc.SubElement(root, "automaton")
        for e in self.estados:
            sub =  ETc.SubElement(doc, "state", id=str(e), name=str(e+1))
            if self.estadoInicial(int(e)):
                ETc.SubElement(sub,"initial")
            if self.estadoFinal(int(e)):
                ETc.SubElement(sub, "final")
        for (e, a) in self.transicoes.keys():
            d = self.transicoes[(e, a)]
            for to in d:
                tran = ETc.SubElement(doc, "transition")
                ETc.SubElement(tran, "from").text = str(e)
                ETc.SubElement(tran, "to").text = str(to)
                ETc.SubElement(tran, "read").text = str(a)
        tree = ETc.ElementTree(root)
        tree.write("{}.jff".format(caminho) ,encoding='utf8', method='xml', short_empty_elements=True)

    def criaCopia(self):
        afn = self
        return afn

    def fecho(self,inicial = int,origem = int,fechoVazio = defaultdict(list)):
        d = self.transicoes[(origem, '¢')]
        for i in d:
            fechoVazio = self.fecho(inicial,i,fechoVazio)
            fechoVazio[(inicial, '¢')].append(i)
        return fechoVazio

    def fechoVazio(self,simbolo):
        """Retorana fecho de estado de origem ate a lista de destionos (Origem, Simbolo) = Destinos[]"""
        fechoVazio = defaultdict(list)
        fechoS = defaultdict(list)
        for o in self.estados:
           fechoVazio = self.fecho(o,o,fechoVazio)
           fechoVazio[(o, '¢')].append(o)
           fechoVazio[(o, '¢')].sort()
        """obtem a lista de destinos da trasição vazia"""
        for (o,s) in fechoVazio.keys():
            origemE = fechoVazio[(o,s)]
            """os destinos das trasições vazias viram origens, e com o determinado simbolo se obtem o novo destino """
            for i in origemE:
                """dS é o novo destino"""
                dS = self.transicoes[(i, simbolo)]
                """ salva em um dicionario a transição da origem do estado verdadeiro, com o simbolo, para o destino d2"""
                for j in dS:
                    if j not in fechoS[(o,simbolo)]:
                        fechoS[(o,simbolo)].append(j)
                fechoS[(o, simbolo)].sort()
        fecho = defaultdict(list)
        """percorre o fecho"""
        for (o,s)in fechoS.keys():
            """ obtem a lista de origens do determinado simbolo"""
            o2 = fechoS[(o,s)]
            """ percorre a lista de origens"""
            if(len(o2)==0):
                """Cria estado de erro"""
                self.criaEstadoFN(-1)
                fecho[(o, simbolo)].append(-1)
            for i in o2:
                """ obtem a lista de destino da transições vazias"""
                d = fechoVazio[(i, '¢')]
                """adiciona os estados de destiono no dicionario"""
                for j in d:
                    if j not in fecho[(o, simbolo)]:
                        fecho[(o,simbolo)].append(j)
        return fecho

    def conversaoAFN_eToAFN(self):
        """É indentificado como movimento vazio o simbolo '¢' na transição """
        s = str()
        for a in self.alfabeto:
            if (a != '¢'):
                s += a
        afn = AutomatoFN(s)
        afn.estados = self.estados
        afn.iniciais = self.iniciais
        afn.finais = self.finais
        """Cria novas transições"""
        for a in self.alfabeto:
            if(a != '¢'):
                fecho = self.fechoVazio(a)
                for (o,s) in fecho.keys():
                    destinos = fecho[(o,s)]
                    for d in destinos:
                        afn.criaTransicao(o,d,a)
        return afn

    def criaEstadoNovo(self,fila = list(), cont = 0 ,estados = defaultdict(list), transicoes = dict()):
        """
        ##### Função retorna ##########
        -- a fila de estados ainda a analizar
        -- dicionario de estados criados a partir do AFN
        -- dicionario de transições já no formato do AFD
        #### na primeira chamada do método....
        -#- Necessario mandar a (fila FIFO) do primeiro estado
        -#- um cont (int) do primeiro estado, geramente 0
        -#- o defaultdict(list), com primeiro estado já adicionado ao dicionario de 'estados'
        -#- e um dict de transicoes, esse pode vir vazio pela primeira vez"""
        """analiza o estado atual, com seus respectivos simbolos"""
        for simbolo in self.alfabeto:
            novoE = list()
            estadoAtual = list(estados[fila[0]])
            for atual in estadoAtual[0]:
                d = self.transicoes[(atual, simbolo)]
                for i in d:
                    novoE.append(i)
                novoE.sort()
            """procura no dicionario, se existe o estado que foi gerado"""
            idNovoE = -1
            for e in estados.keys():
                lista = estados[e]
                if(list(lista[0]) == list(novoE)):
                    idNovoE = e
            """verifica se não existe estado, e cria um novo"""
            if (idNovoE == -1):
                cont +=1
                idNovoE = cont
                estados[idNovoE].append(novoE)
                """Adiciona novo estado a lista"""
                fila.append(idNovoE)
            """obtem o estado de origem no dicionario"""
            origem = 0
            for e in estados:
                lista = estados[e]
                if(list(lista[0]) == list(estadoAtual[0])):
                    origem = e
                    break
            """cria transição"""
            transicoes[(int(origem), str(simbolo))] = int(idNovoE)
        """remove primeiro elemento da fila"""
        fila.pop(0)
        """verifica se existe outro estado para analizar"""
        if(len(fila)>0):
            fila,estados,transicoes = self.criaEstadoNovo(fila,idNovoE,estados,transicoes)
        """quando não tem mais elemento na fila, tetorna os valores do metodo"""
        return fila,estados,transicoes


    def conversaoAfnToAFD(self):
        """FUNÇÃO DE CONVERÇÃO DE AFN PARA AFD (FOI DIFÍCIL, MAIS SAIU!!!!)"""
        afd = AutomatoFD(self.alfabeto)
        """valores pre-definidos que a função exige para funcionar"""
        cont = 0
        fila = list()
        estados = defaultdict(list)
        transicoes = dict()
        """Adiciona o estado inicial ao dicionario de estados"""
        estados[cont].append(self.iniciais)
        """adiciona o primeiro estado 0, a fila"""
        fila.append(cont)
        """cria o primeiro estado e deixa o como INICIAL"""
        afd.criaEstado(cont,True)
        """função recurciva que analiza estado por estado, (alma da conversão)"""
        fila,estados,transicoes = self.criaEstadoNovo(fila,cont,estados,transicoes)
        """percorre o dicionario de estados para criar os novos estados ao AFD"""
        for e in estados.keys():
            lista = estados[e]
            afd.criaEstado(e)
            """verifica se o estado é final"""
            for id in self.finais:
                if (id in lista[0]):
                    """define o estado como final e para o loop, pois é necessario definir apenas uma vez"""
                    afd.mudaEstadoFinal(id,True)
                    break
        """insere as transições ao afd"""
        afd.transicoes = transicoes
        return afd

    def __str__(self):
        """Retorna string descrevendo o AFD. Util para debug."""
        s = 'AFN(E, A, T, i, F): \n'
        s+= '   E = { '
        for e in self.estados:
            s += '{}, '.format(str(e))
        s += '} \n'
        s += '   A = { '
        for a in self.alfabeto:
            s += "'{}', ".format(a)
        s += '} \n'
        s += '   T = { '
        for(e,a) in self.transicoes.keys():
            d = self.transicoes[(e, a)]
            s += "({},'{}')-->{}, ".format(e, a, d)
        s += '} \n'
        s += '    i = { '
        for e in self.iniciais:
            s += '{}, '.format(str(e))
        s += '}'
        s += '    F = { '
        for e in self.finais:
            s += '{}, '.format(str(e))
        s += '}'
        return s

    """######Escripts de teste de AFN#####################"""
    def testeAFNtoAFD(self):
        """Converao de AFN para AFD"""
        afn = AutomatoFN('01')
        for i in range(0, 3):
            afn.criaEstadoFN(i)
        afn.mudaEstadoInicialFN(0, True)
        afn.mudaEstadoFinalFN(2, True)
        afn.criaTransicao(0, 0, '0')
        afn.criaTransicao(0, 0, '1')
        afn.criaTransicao(0, 1, '0')
        afn.criaTransicao(1, 2, '1')
        print(afn)
        afd = AutomatoFD('01')
        afd = afn.conversaoAfnToAFD()
        print(afd)

    def testeAFNEtoAFN(self):
        """Ceria Autonomo FNe"""
        afne = AutomatoFN('ab¢')
        for i in range(0, 5):
            afne.criaEstadoFN(i)
        afne.mudaEstadoInicialFN(0, True)
        afne.mudaEstadoFinalFN(4, True)
        afne.mudaEstadoFinalFN(1, True)
        afne.criaTransicao(0, 1, '¢')
        afne.criaTransicao(0, 2, '¢')
        afne.criaTransicao(2, 3, '¢')
        afne.criaTransicao(1, 3, 'a')
        afne.criaTransicao(2, 1, 'a')
        afne.criaTransicao(3, 1, 'a')
        afne.criaTransicao(4, 4, 'a')
        afne.criaTransicao(3, 1, 'b')
        afne.criaTransicao(3, 2, 'b')
        afne.criaTransicao(2, 4, 'b')
        afne.criaTransicao(4, 2, 'b')
        print(afne)
        afn = afne.conversaoAFN_eToAFN()
        print(afn)

    def salvaAFNarquivo(self):
        """Ceria Autonomo FN"""
        afn = AutomatoFN('ab')
        for i in range(1, 5):
             afn.criaEstadoFN(i)
        afn.mudaEstadoInicialFN(1, True)
        afn.mudaEstadoFinalFN(4, True)
        afn.criaTransicao(1, 2, 'a')
        afn.criaTransicao(1, 1, 'a')
        afn.criaTransicao(3, 4, 'a')
        afn.criaTransicao(4, 3, 'a')
        afn.criaTransicao(1, 3, 'b')
        afn.criaTransicao(3, 1, 'b')
        afn.criaTransicao(2, 4, 'b')
        afn.criaTransicao(4, 2, 'b')
        print(afn)
        """Salva Aoutonomo de arquivo"""
        afn.salvaAFN("./assets/afn")

    def lerAFNarquivo(self):
        """Ler Aoutonomo de arquivo"""
        afn = self.lerAFN("./assets/fn.jff")
        print(afn)

    def testeCriaCopia(self):
        afn = AutomatoFN('01')
        for i in range(0, 3):
            afn.criaEstadoFN(i)
        afn.mudaEstadoInicialFN(0, True)
        afn.mudaEstadoFinalFN(2, True)
        afn.criaTransicao(0, 0, '0')
        afn.criaTransicao(0, 0, '1')
        afn.criaTransicao(0, 1, '0')
        afn.criaTransicao(1, 2, '1')
        print(afn)
        afn2 = afn.criaCopia()
        print(afn2)

if __name__ == '__main__':
    """Ceria Autonomo AFN"""
    afn = AutomatoFN('')










